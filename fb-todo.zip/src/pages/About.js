import React from 'react'

const About = () => {
  return (
    <div className="p-6 mt-5 shadow rounded bg-white">About</div>
  )
}

export default About